package iss.java.mail;

import javax.mail.MessagingException;
import java.io.IOException;

/**
 * 瀹氫箟涓�绯诲垪閭欢鏀跺彂鐨勬祦绋�
 */
public interface IMailService {
    /**
     * 鍒濆鍖栧苟杩炴帴鎵�鏈夌殑閭欢鏈嶅姟鍣�
     * @throws MessagingException 鍒濆鍖栨垨杩炴帴寮傚父
     */
    public void connect() throws MessagingException;

    /**
     * 鍙戦�佸崟灏侀偖浠�
     * @param recipient 鏀朵欢浜洪偖绠卞湴鍧�
     * @param subject 閭欢涓婚
     * @param content 閭欢姝ｆ枃
     * @throws MessagingException 鍙戦�侀偖浠堕敊璇�
     */
    public void send(String recipient, String subject, Object content) throws MessagingException;

    /**
     * 璇㈤棶鏈嶅姟鍣ㄦ槸鍚︽湁鏂伴偖浠跺埌杈�
     * @return 甯冩湕鍊硷紝鎸囩ず鏄惁鏈夋柊閭欢
     * @throws MessagingException 璇㈤棶鏈嶅姟鍣ㄥ嚭閿�
     */
    public boolean listen() throws MessagingException;

    /**
     * 鎺ユ敹鑷姩鍥炲鐨勫唴瀹癸紝骞惰浆鎹负瀛楃涓�
     * 娉細鐢ㄤ綘鑳芥兂鍒扮殑浠绘剰鏂规硶瀵绘壘鍥炲閭欢鍧囧彲锛屽苟涓嶄竴瀹氳鐢ㄥ埌杩欎袱涓弬鏁�
     * @param sender 鑷姩鍥炲鐨勫彂浠朵汉閭鍦板潃
     * @param subject 鑷姩鍥炲鐨勪富棰�
     * @return 鑷姩鍥炲鐨勫唴瀹瑰瓧绗︿覆
     * @throws MessagingException 鏌ヨ閭欢寮傚父
     * @throws IOException 涓嬭浇閭欢寮傚父
     */
    public String getReplyMessageContent(String sender, String subject) throws MessagingException;


}

